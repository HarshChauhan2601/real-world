<?php

namespace WP_Rplg_Google_Reviews\Includes;

class Deactivator {

    public function deactivate() {

    }

}
